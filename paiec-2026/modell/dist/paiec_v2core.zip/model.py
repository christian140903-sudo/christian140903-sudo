"""PAIEC 2026 submission: hierarchical logistic pair-level predictor (no LLM, no network, stdlib only).

logit r_sb = c_b + a_b * m_s + v_sb. m_s: subject ability learned on measurement-db (rev 54074453) via
normalized_name, else a ridge regression on visible metadata. c_b, a_b: benchmark location and slope, unknown at
test time (cold start); their Laplace posterior uses the revealed labels of ALL subjects of the benchmark in
`labeled`. v_sb: pair deviation. Prediction = posterior mean of sigmoid (probit approximation), optional Platt
recalibration per label stage (kept only where cross-fitted calibration lowered the Brier score). v2.0-core: staged
fallback hier -> beta-binomial -> 0.5 and tolerant label parsing; predict() never raises. Built 2026-10-20T20:18Z, state sha256 3c46e5bd4496d360.
"""
# ---- merkmale.py ----
"""Subjekt-Merkmale — NUR Standardbibliothek (identisch in Training und Paket).

Nur Felder, die zur Testzeit sichtbar sind (Wettbewerbsseite, Predictor Interface): die 8 Subjektfelder als Strings.
"""
import math
import re

FELDER = ("normalized_name", "provider", "release_date", "access_date", "harness", "harness_version",
          "reasoning_effort", "subject_features_extra")
_TOKEN = re.compile(r"[a-z0-9]+(?:\.[0-9]+)?")
_GROESSE = re.compile(r"(?<![a-z0-9.])(\d+(?:\.\d+)?)\s*([bm])(?![a-z0-9])")
_DATUM = re.compile(r"^\s*(\d{4})(?:-(\d{1,2}))?")


def _s(x):
    return "" if x is None else str(x)


def konfig(subject):
    """Volle Testzeit-Identität: alle 8 Felder. Gleiche Konfig = für den Prädiktor dasselbe Subjekt."""
    return "\x1f".join([_s(subject.get(f)) for f in FELDER])


def name_schluessel(subject):
    n = " ".join(_s(subject.get("normalized_name")).split()).casefold()
    return n or None


def jahr(datum):
    m = _DATUM.match(_s(datum))
    if not m:
        return None
    j = int(m.group(1))
    if not 1990 <= j <= 2100:
        return None
    monat = int(m.group(2)) if m.group(2) else 6
    return j + (min(max(monat, 1), 12) - 0.5) / 12.0


def groesse_mrd(name):
    """Parameterzahl in Milliarden aus dem Namen ('70B', '1.5b', '350M'), sonst None."""
    werte = []
    for zahl, einheit in _GROESSE.findall(name):
        v = float(zahl) / (1000.0 if einheit == "m" else 1.0)
        if 0.01 <= v <= 5000:
            werte.append(v)
    return max(werte) if werte else None


def tokens(name):
    return sorted(set(_TOKEN.findall(name)))


def meta_merkmale(subject):
    """-> dict Merkmal -> Wert (dünn). Vokabular wird im Training festgelegt; unbekannte Schlüssel wirken 0."""
    name = name_schluessel(subject) or ""
    x = {}
    prov = " ".join(_s(subject.get("provider")).split()).casefold()
    if prov:
        x["prov=" + prov] = 1.0
    else:
        x["prov_fehlt"] = 1.0
    if not name:
        x["name_fehlt"] = 1.0
    for t in tokens(name):
        x["tok=" + t] = 1.0
    g = groesse_mrd(name)
    if g is None:
        x["groesse_fehlt"] = 1.0
    else:
        x["log10_groesse"] = math.log10(g)
    j = jahr(subject.get("release_date"))
    if j is None:
        x["jahr_fehlt"] = 1.0
    else:
        x["jahr"] = j - 2024.0
    if _s(subject.get("harness")).strip():
        x["harness_da"] = 1.0
    if _s(subject.get("reasoning_effort")).strip():
        x["effort_da"] = 1.0
    return x

# ---- inferenz.py ----
"""Hierarchischer logistischer Prädiktor auf Paarebene — NUR Standardbibliothek (geht unverändert ins Paket).

Modell für die Erfolgsquote r eines Subjekt-Benchmark-Paares (Items zufällig gezogen, je Item eine Antwort):
    logit r_sb = c_b + a_b * m_s + v_sb
  m_s     Subjekt-Fähigkeit aus dem Training (Lookup über normalized_name), sonst Metadaten-Regression
  c_b     Benchmark-Lage, Prior N(mu_c, tau_c2) — kalter Start, Posterior aus den Labels ALLER Subjekte des Benchmarks
  a_b     Benchmark-Steigung auf der Fähigkeit, Prior N(lam, tau_l2) — dito
  v_sb    Paar-Abweichung, Prior N(0, s2_s) mit s2_s = tau_v2 + kappa * V_s (V_s = Unsicherheit von m_s),
          für unbekannte Subjekte s2_unk
Item-Stufe (optional, tau_i2 > 0): Labels ANDERER Subjekte zum selben Item (gleicher Text + Merkmale, gleiche
benchmark_id) verschieben das Zielitem um d_i ~ N(0, tau_i2); ohne solche Labels bleibt die Paarvorhersage exakt.
Labels y ~ Bernoulli(sigma(logit r_sb)). Posterior von (c, a, v_1..v_G) per Laplace; die Hesse-Matrix ist eine
Pfeilspitze mit 2x2-Kopf, Newton-Schritte exakt in O(G) über das Schur-Komplement. Vorhersage = Posterior-Mittel
von sigma(eta) per Probit-Näherung sigma(m / sqrt(1 + pi*var/8)); danach optional Platt je Budget-Stufe.
"""
import hashlib
import json
import math


STUFEN = (0, 1, 3, 7, 15, 31)

# v2.0-core (Härtung K4b, 2026-10-20): robustes Label-Parsing. v1 rechnete float(lab) >= 0.5 und warf bei "true"/"yes"/
# None eine Ausnahme (-> Rückfall 0,5 für den ganzen Aufruf). Für bool/int/float/numerische Strings ist das Ergebnis
# bitgleich zu v1; zusätzlich werden true/yes/false/no (Groß/Klein egal) erkannt, None/NaN/Unlesbares übersprungen.
_WAHR = frozenset(("true", "yes", "y", "t", "correct", "pass"))
_FALSCH = frozenset(("false", "no", "n", "f", "incorrect", "fail"))


def label_wert(lab):
    """Label -> 1.0 / 0.0 / None (None = überspringen)."""
    if lab is None:
        return None
    if isinstance(lab, bool):
        return 1.0 if lab else 0.0
    if isinstance(lab, str):
        s = lab.strip().casefold()
        if s in _WAHR:
            return 1.0
        if s in _FALSCH:
            return 0.0
        try:
            v = float(s)
        except ValueError:
            return None
    else:
        try:
            v = float(lab)
        except (TypeError, ValueError):
            return None
    if v != v:
        return None
    return 1.0 if v >= 0.5 else 0.0


def _label_zeichen(lab):
    y = label_wert(lab)
    return "x" if y is None else ("1" if y >= 0.5 else "0")


def sigmoid(x):
    if x >= 0:
        return 1.0 / (1.0 + math.exp(-x))
    e = math.exp(x)
    return e / (1.0 + e)


def logit(p):
    p = min(max(p, 1e-12), 1.0 - 1e-12)
    return math.log(p / (1.0 - p))


def _log1pexp(x):
    return x + math.log1p(math.exp(-x)) if x > 0 else math.log1p(math.exp(x))


def stufe(n):
    s = 0
    for b in STUFEN:
        if n >= b:
            s = b
    return s


def posterior(gruppen, mu_c, tau_c2, lam, tau_l2, iter_max=60):
    """gruppen: Liste (m, s2, k, n) je Subjekt-Gruppe mit Labels in diesem Benchmark.
    -> dict c, a, v[], d[], h[], Sigma_kopf (2x2 als (scc, sca, saa))."""
    G = len(gruppen)
    c, a = mu_c, lam
    v = [0.0] * G

    def ziel(c, a, v):
        f = (c - mu_c) ** 2 / (2 * tau_c2) + (a - lam) ** 2 / (2 * tau_l2)
        for (m, s2, k, n), vg in zip(gruppen, v):
            e = c + a * m + vg
            f += n * _log1pexp(e) - k * e + vg * vg / (2 * s2)
        return f

    f_alt = ziel(c, a, v)
    h = [0.0] * G
    d = [0.0] * G
    for _ in range(iter_max):
        gc = (c - mu_c) / tau_c2
        ga = (a - lam) / tau_l2
        acc, aca, aaa = 1.0 / tau_c2, 0.0, 1.0 / tau_l2
        rc = ra = 0.0
        gv = [0.0] * G
        for j, ((m, s2, k, n), vg) in enumerate(zip(gruppen, v)):
            p = sigmoid(c + a * m + vg)
            r = n * p - k
            hh = n * p * (1.0 - p)
            gc += r
            ga += r * m
            g_v = r + vg / s2
            dd = hh + 1.0 / s2
            acc += hh - hh * hh / dd
            aca += hh * m - hh * hh * m / dd
            aaa += hh * m * m - hh * hh * m * m / dd
            rc += hh * g_v / dd
            ra += hh * m * g_v / dd
            gv[j], h[j], d[j] = g_v, hh, dd
        det = acc * aaa - aca * aca
        b1, b2 = -gc + rc, -ga + ra
        x0 = (aaa * b1 - aca * b2) / det
        x1 = (acc * b2 - aca * b1) / det
        dv = [(-gv[j] - h[j] * x0 - h[j] * gruppen[j][0] * x1) / d[j] for j in range(G)]
        schritt = 1.0
        while True:
            c_n, a_n = c + schritt * x0, a + schritt * x1
            v_n = [vg + schritt * dx for vg, dx in zip(v, dv)]
            f_neu = ziel(c_n, a_n, v_n)
            if f_neu <= f_alt + 1e-12 or schritt < 1e-4:
                break
            schritt *= 0.5
        delta = max([abs(schritt * x0), abs(schritt * x1)] + [abs(schritt * dx) for dx in dv])
        c, a, v, f_alt = c_n, a_n, v_n, f_neu
        if delta < 1e-9:
            break
    # Krümmung am Modus
    acc, aca, aaa = 1.0 / tau_c2, 0.0, 1.0 / tau_l2
    for j, ((m, s2, k, n), vg) in enumerate(zip(gruppen, v)):
        p = sigmoid(c + a * m + vg)
        hh = n * p * (1.0 - p)
        dd = hh + 1.0 / s2
        acc += hh - hh * hh / dd
        aca += hh * m - hh * hh * m / dd
        aaa += hh * m * m - hh * hh * m * m / dd
        h[j], d[j] = hh, dd
    det = acc * aaa - aca * aca
    return {"c": c, "a": a, "v": v, "h": h, "d": d, "m": [g[0] for g in gruppen],
            "S": (aaa / det, -aca / det, acc / det)}


def praediktiv(post, idx, m_t, s2_t):
    """Mittel und Varianz von eta für das Zielsubjekt. idx = Gruppenindex oder None (keine eigenen Labels)."""
    scc, sca, saa = post["S"]
    var_kopf = scc + 2 * m_t * sca + m_t * m_t * saa
    if idx is None:
        return post["c"] + post["a"] * m_t, var_kopf + s2_t
    hh, dd = post["h"][idx], post["d"][idx]
    # b = (hh, hh*m_t); Sigma_kopf b
    sb0 = scc * hh + sca * hh * m_t
    sb1 = sca * hh + saa * hh * m_t
    u_sb = sb0 + m_t * sb1
    b_sb = hh * sb0 + hh * m_t * sb1
    var = var_kopf - 2.0 * u_sb / dd + 1.0 / dd + b_sb / (dd * dd)
    return post["c"] + post["a"] * m_t + post["v"][idx], var


def wahrscheinlichkeit_aus(mittel, var):
    return sigmoid(mittel / math.sqrt(1.0 + math.pi * max(var, 0.0) / 8.0))


class Modell:
    """state: dict aus training.exportiere(); Schalter für Ablationen."""

    def __init__(self, state, subjektwissen=True, steigung=True, kalibrierung=True, item_effekt=True):
        self.state = state
        self.theta = state["theta"]
        self.meta_b0 = state["meta"]["b0"]
        self.meta_w = state["meta"]["w"]
        hy = state["hyp"] if subjektwissen else state["hyp_null"]
        self.mu_c, self.tau_c2 = hy["mu_c"], hy["tau_c2"]
        self.lam = hy["lam"]
        self.tau_l2 = hy["tau_l2"] if steigung else 1e-8
        self.tau_v2, self.kappa, self.s2_unk = hy["tau_v2"], hy["kappa"], hy["s2_unk"]
        self.subjektwissen = subjektwissen
        self.platt = {int(k): tuple(v) for k, v in (state.get("platt") or {}).items()} if kalibrierung else {}
        self.clip = state.get("clip", 1e-4)
        self.tau_i2 = float(state["hyp"].get("tau_i2", 0.0)) if item_effekt else 0.0
        self._prior_cache = {}
        self.leere_cache()

    # --- Subjekt-Prior ---
    def subjekt_prior(self, subject):
        key = konfig(subject)
        if key in self._prior_cache:
            return self._prior_cache[key]
        if not self.subjektwissen:
            out = (0.0, self.s2_unk)
        else:
            nk = name_schluessel(subject)
            if nk is not None and nk in self.theta:
                m, V = self.theta[nk]
                out = (m, self.tau_v2 + self.kappa * V)
            else:
                x = meta_merkmale(subject)
                m = self.meta_b0 + sum(self.meta_w.get(f, 0.0) * w for f, w in x.items())
                out = (m, self.s2_unk)
        self._prior_cache[key] = out
        return out

    # --- Labels gruppieren (einmal je Label-Menge) ---
    @staticmethod
    def fingerabdruck(labeled):
        hsh = hashlib.sha1(str(len(labeled)).encode())
        for (subj, it), lab in labeled:
            text = str(it.get("item_content", "") or "")
            hsh.update(("%s\x1f%s\x1f%d\x1f%s\x1f%s\x1e" % (it.get("benchmark_id", ""), konfig(subj), len(text),
                                                          text[:64], _label_zeichen(lab))).encode())
        return hsh.hexdigest()

    def leere_cache(self):
        self._fp, self._gruppen, self._items, self._post, self._ipost = None, {}, {}, {}, {}

    @staticmethod
    def item_schluessel(item):
        """Item-Identität zur Testzeit: Text + Merkmale (interactors gehören zur Antwort, nicht zum Item)."""
        text = str((item or {}).get("item_content", "") or "")
        merk = str((item or {}).get("item_features", "") or "")
        return (text + "\x1f" + merk) if (text or merk) else None

    # Laufzeit-Begrenzung (REVIEW M3, 2026-10-20): bis VOLL_BIS Labels exakter Fingerabdruck über alle Labels (alte
    # Fassung, unverändert); darüber ein Stichproben-Schlüssel aus Länge + STICHPROBE gleich verteilten Einträgen
    # (inkl. erstem und letztem), Kosten je Aufruf unabhängig von |labeled|. Er verwechselt zwei Label-Mengen nur, wenn
    # sie gleich lang sind, an allen Stichprobenpositionen übereinstimmen und nacheinander ohne leere_cache() an
    # dasselbe Modell gehen. Auf der Plattform wächst |labeled| je Checkpoint streng (verschachtelte Budgets, je Paar
    # >= 40 Akquise-Items >= 31), innerhalb eines Checkpoints ist labeled für alle Ziele gleich.
    VOLL_BIS = 1024
    STICHPROBE = 64

    @classmethod
    def stichproben_schluessel(cls, labeled):
        n = len(labeled)
        k = cls.STICHPROBE
        pos = sorted({(j * (n - 1)) // (k - 1) for j in range(k)})
        hsh = hashlib.sha1(("s%d" % n).encode())
        for i in pos:
            (subj, it), lab = labeled[i]
            text = str(it.get("item_content", "") or "")
            hsh.update(("%d\x1f%s\x1f%s\x1f%d\x1f%s\x1f%s\x1e" % (i, it.get("benchmark_id", ""), konfig(subj), len(text),
                                                              text[:64], _label_zeichen(lab))).encode())
        return "s" + hsh.hexdigest()

    def _bereite(self, labeled):
        if not labeled:
            # Budget 0: nie Gruppen aus einer früheren Label-Menge weiterverwenden (Leck, 2026-10-20 gefunden)
            self._fp, self._gruppen, self._items, self._post, self._ipost = "", {}, {}, {}, {}
            return
        if len(labeled) > self.VOLL_BIS:
            fp = self.stichproben_schluessel(labeled)
            self._liste = None  # Schnellpfad der exakten Fassung nie mit einer großen Liste mischen
            if fp == self._fp:
                return
        else:
            # Schnellpfad: dasselbe Listenobjekt (Referenz gehalten -> keine id-Wiederverwendung), gleiche Länge,
            # gleiche Ränder, gleiche Label-Summe -> Fingerabdruck sparen. In-place-Änderungen der Mitte ohne
            # Label-Änderung würden nicht erkannt; die Plattform baut labeled je Ereignis neu (streaming_ingestion.py).
            summe = sum(1 for _, lab in labeled if label_wert(lab) == 1.0)
            if (self._fp and labeled is getattr(self, "_liste", None) and len(labeled) == self._schnell[0]
                    and summe == self._schnell[1] and labeled[0] == self._rand[0] and labeled[-1] == self._rand[1]):
                return
            fp = self.fingerabdruck(labeled)
            self._liste, self._schnell, self._rand = labeled, (len(labeled), summe), (labeled[0], labeled[-1])
            if fp == self._fp:
                return
        gruppen, items = {}, {}
        for (subj, it), lab in labeled:
            bid = it.get("benchmark_id") or ""
            if not bid:
                continue
            y = label_wert(lab)
            if y is None:  # v2.0-core: unlesbares Label überspringen statt Ausnahme (v1: float() warf)
                continue
            g = gruppen.setdefault(bid, {})
            kf = konfig(subj)
            if kf not in g:
                m, s2 = self.subjekt_prior(subj)
                g[kf] = [m, s2, 0.0, 0.0]
            g[kf][2] += y
            g[kf][3] += 1.0
            if self.tau_i2 > 0:
                ik = self.item_schluessel(it)
                if ik is not None:
                    items.setdefault(bid, {}).setdefault(ik, []).append((kf, y))
        self._fp, self._gruppen, self._items, self._post, self._ipost = fp, gruppen, items, {}, {}

    def _posterior(self, bid):
        if bid not in self._post:
            g = self._gruppen.get(bid, {})
            schl = list(g.keys())
            post = posterior([tuple(g[k]) for k in schl], self.mu_c, self.tau_c2, self.lam, self.tau_l2)
            post["index"] = {k: i for i, k in enumerate(schl)}
            post["n"] = [g[k][3] for k in schl]
            post["p_kal"] = {}
            self._post[bid] = post
        return self._post[bid]

    def kalibriere(self, p, n_eigen):
        ab = self.platt.get(stufe(n_eigen))
        if ab:
            p = sigmoid(ab[0] * logit(p) + ab[1])
        return min(max(p, self.clip), 1.0 - self.clip)

    def _p_gruppe(self, bid, kf):
        """Kalibrierte Paar-Wahrscheinlichkeit einer Gruppe mit Labels (für die Item-Stufe)."""
        post = self._posterior(bid)
        if kf not in post["p_kal"]:
            idx = post["index"][kf]
            g = self._gruppen[bid][kf]
            mittel, var = praediktiv(post, idx, g[0], g[1])
            post["p_kal"][kf] = self.kalibriere(wahrscheinlichkeit_aus(mittel, var), post["n"][idx])
        return post["p_kal"][kf]

    def _item_post(self, bid, ik):
        """Posterior der Item-Abweichung d ~ N(0, tau_i2) aus Labels aller Subjekte zu diesem Item.
        Bedingte Logits beta_t = logit(p_t) * c, c = sqrt(1 + pi tau_i2 / 8) (inverse Probit-Näherung), damit ohne
        Item-Labels exakt die Paar-Wahrscheinlichkeit herauskommt."""
        key = (bid, ik)
        if key in self._ipost:
            return self._ipost[key]
        c = math.sqrt(1.0 + math.pi * self.tau_i2 / 8.0)
        obs = [(logit(self._p_gruppe(bid, kf)) * c, y) for kf, y in self._items[bid][ik]]
        d = 0.0
        for _ in range(50):
            g, h = d / self.tau_i2, 1.0 / self.tau_i2
            for bt, y in obs:
                p = sigmoid(bt + d)
                g += p - y
                h += p * (1.0 - p)
            schritt = max(min(g / h, 3.0), -3.0)
            d -= schritt
            if abs(schritt) < 1e-10:
                break
        h = 1.0 / self.tau_i2 + sum(sigmoid(bt + d) * (1.0 - sigmoid(bt + d)) for bt, _ in obs)
        self._ipost[key] = (d, 1.0 / h, c)
        return self._ipost[key]

    def wahrscheinlichkeit(self, input, labeled=None):
        subject, item = input
        m_t, s2_t = self.subjekt_prior(subject)
        bid = (item or {}).get("benchmark_id") or ""
        self._bereite(labeled or [])
        if bid and bid in self._gruppen:
            post = self._posterior(bid)
            idx = post["index"].get(konfig(subject))
            n_eigen = post["n"][idx] if idx is not None else 0
        else:
            post = posterior([], self.mu_c, self.tau_c2, self.lam, self.tau_l2) if not hasattr(self, "_leer") \
                else self._leer
            self._leer = post
            idx, n_eigen = None, 0
        mittel, var = praediktiv(post, idx, m_t, s2_t)
        p = self.kalibriere(wahrscheinlichkeit_aus(mittel, var), n_eigen)
        if self.tau_i2 > 0 and bid in self._items:
            ik = self.item_schluessel(item)
            if ik is not None and ik in self._items[bid]:
                d, v, c = self._item_post(bid, ik)
                p = sigmoid((logit(p) * c + d) / math.sqrt(1.0 + math.pi * v / 8.0))
                p = min(max(p, self.clip), 1.0 - self.clip)
        return float(p)



_STATE_JSON = r'''{"als":{"lam":1.841803600079995,"sigma_e2":0.15188055743552029},"baselines":{"beta_alpha":1.4181561330799144,"beta_beta":1.316076816738518,"globale_quote":0.5186669018724566},"clip":0.0001,"herkunft":{"benchmarks":151,"cv":"cv_A","paare":14269,"revision":"54074453da7b9911be0f48e4c560be547bc84d21","zeit_utc":"2026-10-20T14:53:52Z"},"herkunft_v2core":{"aenderung":"nur platt: Stufen nach Schnittregel KERN-DIFF.md \u00a70 (v1-Gesamtwahl UND jede Falten-Wahl, cv_V2K1)","basis":"paket/state_final.json sha256 046e55c5cf5a8c337a60b1bc07fd3cc5c38c1809648fda267ba8226b9cd3bae4 (v1, unver\u00e4ndert)","platt_v1":{"0":[1.3421460603265656,-0.37339785516509566],"1":[1.046130321050477,-0.16129507329838566],"3":[1.0413427829741364,-0.07999882471561529],"7":[1.0365034600161656,-0.04219805948997325]},"platt_v2core_stufen":["0","1"],"stufenwahl_je_falte":{"0":[0,1,3,7,15],"1":[0,1,3],"2":[0,1,3],"3":[0,1,3,7],"4":[0,1,3,7],"5":[0,1,7],"6":[0,1,3,7,15,31],"7":[0,1,3,7],"8":[0,1,7],"9":[0,1,3]},"zeit_utc":"2026-10-20T20:18:20Z"},"hyp":{"kappa":3.2166912404879153,"lam":0.3989124263898666,"mu_c":0.31513105013614395,"n_bloecke":142,"nll_je_paar":1.4043904819562079,"s2_unk":0.7895019506800088,"tau_c2":1.3681986134011903,"tau_i2":2.5512090688966684,"tau_i2_benchmarks":121,"tau_l2":0.16354632739554992,"tau_v2":0.3181401521569475},"hyp_null":{"kappa":0.0,"lam":0.0,"mu_c":0.35788195743683004,"n_bloecke":142,"nll_je_paar":1.4488299528361384,"s2_unk":0.6563292313134751,"tau_c2":1.2976116792797099,"tau_i2":2.5512090688966684,"tau_l2":1e-08,"tau_v2":0.6563292313134751},"meta":{"b0":-0.4980824840679285,"w":{"effort_da":0.06484108755214474,"groesse_fehlt":0.4659596901910475,"harness_da":0.06258028265392791,"jahr":0.1972605485960375,"jahr_fehlt":0.21918420151449333,"log10_groesse":0.206795865120858,"name_fehlt":-0.1160495464393201,"prov=(agent scaffold)":0.2416246850797701,"prov=01.ai":-0.18713433135603766,"prov=ai21":0.03792300089022624,"prov=aidc-ai":0.14571781998970565,"prov=aleph alpha":0.14483334238570106,"prov=alibaba":0.12384092917898037,"prov=allenai":-0.20000380512160212,"prov=amazon":0.10413886267543909,"prov=ant group":0.10249781192449954,"prov=anthropic":0.1537268330246226,"prov=baai":0.0525807069065744,"prov=baidu":-0.07348845852923891,"prov=bytedance":0.07057844000402017,"prov=cambrian":0.06034685890526336,"prov=cohere":0.0019145388959787184,"prov=community":0.13497341919123998,"prov=deepseek":0.10699008994949533,"prov=eleutherai":-0.12762828777200977,"prov=google":0.010614917767962815,"prov=hugging face":-0.06718190505962823,"prov=ibm":-0.12083935748877427,"prov=llava":0.018737464191860845,"prov=meta":0.17139880790933193,"prov=microsoft":0.02780383210980797,"prov=minimax":-0.005338545253020255,"prov=mistral":-0.21681198754999834,"prov=moonshot":0.10737845960292278,"prov=nvidia":0.08240579122457681,"prov=openai":0.15265759397474388,"prov=openbmb":0.05594652227466233,"prov=opengvlab":0.2657021726360597,"prov=salesforce":0.07698691860961807,"prov=scb10x":0.08631305348148019,"prov=shanghai ai lab":0.1329468526720661,"prov=stability ai":-0.15130600110555648,"prov=stanford":-0.4682960785839022,"prov=stepfun":0.030330854137565803,"prov=tencent":0.15321188556309456,"prov=tiger-lab":0.009434294311137103,"prov=tii":0.20924597166175318,"prov=unknown":0.2854066742451235,"prov=vision-cair":-0.30769187974390216,"prov=writer":-0.01044304202010411,"prov=xai":0.04794038317248739,"prov=xiaomi":0.026216240159588164,"prov=zhipu":0.07041276260220537,"prov_fehlt":-0.11604954643933414,"tok=0":-0.024995077341815723,"tok=01":-0.18713433135603805,"tok=1":0.07080833320854274,"tok=1.0":-0.13325373036869392,"tok=1.5":-0.1396728774070422,"tok=1.6":-0.12629286129583164,"tok=11b":0.058259971819011984,"tok=12b":0.04768747935521768,"tok=13b":0.21575845580085234,"tok=14b":0.3116309482472086,"tok=1b":-0.21882900870654434,"tok=2":-0.10310170391371025,"tok=2.0":-0.0488719640008653,"tok=2.5":0.07255998460367431,"tok=2.6":0.1555971400336723,"tok=235b":-0.061458077564741406,"tok=26b":0.02215724422243077,"tok=27b":0.23500021341922034,"tok=2b":0.04036314382766277,"tok=3":0.09679020482069077,"tok=3.1":-0.038288311858185445,"tok=3.2":-0.027645759307502314,"tok=3.3":0.07944783216406602,"tok=3.5":-0.0627302397645402,"tok=30b":-0.03912292640596248,"tok=32b":0.006774748316799376,"tok=34b":0.054230542367689906,"tok=3b":0.1707019015272545,"tok=4":-0.011920478304379587,"tok=4.1":-0.10627648124070557,"tok=4.5":0.02312103622974523,"tok=4.6":-0.21837632415395414,"tok=4.7":0.04584975560203507,"tok=405b":0.07745606315775094,"tok=40b":0.08376581857633578,"tok=4b":0.08408917001848076,"tok=4v":-0.064232722690197,"tok=5":0.20836700983942308,"tok=5.2":0.07389813386802072,"tok=5.4":-0.026261037622020814,"tok=5.6":-0.01689133824161876,"tok=6b":-0.200978349648989,"tok=70b":0.08626651858652377,"tok=72b":0.04427788318995026,"tok=7b":-0.12356827155942263,"tok=8b":0.05022775964593344,"tok=9b":-0.0027131275092348336,"tok=a3b":-0.024011416922663703,"tok=agent":0.24162468507977267,"tok=ai":0.3605855742684147,"tok=ai21":0.03792300089022635,"tok=aidc":0.1457178199897056,"tok=aleph":0.14483334238570053,"tok=alibaba":-0.025775423329439134,"tok=allenai":-0.20000380512160285,"tok=alpaca":-0.3346570594976464,"tok=alpha":0.14483334238570075,"tok=amazon":0.10413886267543913,"tok=ant":0.1024978119244996,"tok=anthropic":0.1537268330246241,"tok=b":-0.13103379703596538,"tok=baai":0.009975480498090723,"tok=baidu":-0.07348845852923916,"tok=bailing":0.09484366965918427,"tok=baseline":0.11741441938855982,"tok=bytedance":0.07057844000402051,"tok=cambrian":0.060346858905263284,"tok=claude":0.1537268330246241,"tok=code":-0.07166227065851356,"tok=coder":-0.12306650701272782,"tok=cohere":0.0019145388959785818,"tok=command":0.0019145388959785805,"tok=context":-0.015394157574973798,"tok=counterfactual":0.07290844540968042,"tok=deepseek":0.1069900899494949,"tok=diffusion":-0.15130600110555698,"tok=distill":-0.3341408951485878,"tok=doubao":-0.10584191350745209,"tok=eagle":0.0866838093595323,"tok=eleutherai":-0.12762828777201057,"tok=emotional":0.6143785279505805,"tok=face":0.013745505940871322,"tok=falcon":0.20924597166175343,"tok=flash":0.013228256060244222,"tok=gemini":0.2431294076821629,"tok=gemma":-0.3191812467989264,"tok=gemma2":0.05765289452475752,"tok=glm":0.16233980952566687,"tok=google":0.010614917767963795,"tok=gpt":-0.0353987621068719,"tok=granite":-0.12083935748877456,"tok=grok":0.04794038317248743,"tok=grpo":0.37986812920651525,"tok=haiku":-0.35668809088473974,"tok=hinge":-0.2776517877214534,"tok=hugging":0.013745505940871292,"tok=huggingface":-0.08092741100050475,"tok=hunyuan":-0.15201905586143513,"tok=ibm":-0.1208393574887745,"tok=igg":1.5371131891911687,"tok=instruct":-0.21364140944670718,"tok=instructblip":0.09755577107060846,"tok=internlm":0.15044394868264097,"tok=internvl":-0.012576730416753437,"tok=internvl2":0.1255808539217275,"tok=internvl2.5":0.152698049131081,"tok=interrogation":-0.5971367103730533,"tok=kimi":0.034086122341340785,"tok=lab":0.009434294311137133,"tok=large":0.09131246063124672,"tok=length":-0.2776517877214531,"tok=lite":-0.028355025146767427,"tok=llama":0.03159245620916382,"tok=llama3":0.013547789818242385,"tok=llava":0.018737464191861605,"tok=long":-0.01539415757497344,"tok=luminous":0.14483334238570067,"tok=mantis":0.009434294311137124,"tok=max":0.15506146922372419,"tok=medium":0.12286476275396593,"tok=meta":-0.4716700200937402,"tok=microsoft":0.027803832109807827,"tok=mimo":0.02621624015958812,"tok=mini":-0.10221599020639707,"tok=minicpm":0.03891494933530634,"tok=minigpt":-0.30769187974390283,"tok=minimax":-0.005338545253020846,"tok=mistral":-0.13714039120640392,"tok=mm":0.07427481719819355,"tok=molmo":0.3910727290074408,"tok=monitor":-1.7430185013952484,"tok=moonshot":0.10737845960292229,"tok=nano":-0.35535487794606235,"tok=nemotron":0.04153671731682283,"tok=next":0.028872847694956665,"tok=nova":0.10413886267543908,"tok=nvidia":0.08240579122457696,"tok=o":-0.29901375450250933,"tok=olmo":-0.06192887365879896,"tok=onevision":0.12907345022930247,"tok=only":0.8738617209135522,"tok=openai":0.15265759397474662,"tok=openbmb":0.05594652227466237,"tok=opengvlab":0.26570217263605944,"tok=opus":-0.029176280611217766,"tok=output":-0.35985049256932305,"tok=ovis1.6":-0.01676018395734646,"tok=ovis2":0.1145783960189391,"tok=palm":0.07353184812017463,"tok=palmyra":-0.010443042020103991,"tok=penalty":-0.27765178772145294,"tok=phi":-0.2315141708193768,"tok=plus":0.17738676020917904,"tok=pro":0.18880637604937645,"tok=pythia":-0.12762828777201046,"tok=qwen":-0.015360575550517336,"tok=qwen1.5":-0.19507979630644856,"tok=qwen2":0.2987043426720249,"tok=qwen2.5":0.14313980063039242,"tok=qwen3":-0.10018133688517807,"tok=qwen3.5":-0.069211654599936,"tok=qwen3.6":-0.008394476894416537,"tok=r1":-0.11225857411982498,"tok=sa":-0.24493364188880373,"tok=salesforce":0.07698691860961805,"tok=scb10x":0.0863130534814803,"tok=scratchpad":-0.5093062879123424,"tok=seed":0.029848541531654844,"tok=short":0.000991999973519045,"tok=slime":-0.10358715866012805,"tok=small":-0.012460990477776613,"tok=smollm2":-0.19888382880558805,"tok=smolvlm":0.05987459372322926,"tok=smolvlm2":0.05808182408185296,"tok=sonnet":0.010255945683223513,"tok=stability":-0.151306001105557,"tok=stable":-0.15130600110555695,"tok=stanford":-0.4682960785839031,"tok=step":0.18320532179083288,"tok=stepfun":0.030330854137565855,"tok=sycophancy":-0.7496492276018417,"tok=tencent":0.15321188556309448,"tok=tgg":1.3802045017398934,"tok=thinking":0.19417298905499814,"tok=tiger":0.009434294311137117,"tok=tii":0.20924597166175335,"tok=training":-0.7496492276018417,"tok=turbo":0.03273384193609683,"tok=typhoon":0.08631305348148023,"tok=v":0.08438638360588532,"tok=v2":-0.10426166257645682,"tok=v2.5":0.0654844645668,"tok=v4":-0.22357075975257207,"tok=vicuna":0.5583912279019226,"tok=vila":0.051137044823914055,"tok=vision":0.2518473100856967,"tok=vl":0.026966870118309588,"tok=vl2":0.027129596284477326,"tok=writer":-0.010443042020103996,"tok=x":0.01309399162588694,"tok=x5":0.0936801706580481,"tok=xai":0.04794038317248745,"tok=xiaomi":0.026216240159561286,"tok=yi":-0.015932181624640586,"tok=zhipu":0.07041276260210781}},"meta_info":{"alpha":1,"n_einheiten":8533,"n_merkmale":259},"platt":{"0":[1.3421460603265656,-0.37339785516509566],"1":[1.046130321050477,-0.16129507329838566]},"rueckfall":0.5,"theta":{"01.ai yi 34b":[-0.30660809937714895,0.08463756700090701],"01.ai yi 6b":[-0.761575405660381,0.046216835614263624],"01.ai yi vision":[0.36394223234666445,0.04987280883753316],"01.ai yi-vl 34b":[0.11419288128053144,0.04980976633898581],"01.ai yi-vl 6b":[-0.004792241444134348,0.04978931981947058],"agent: agi agent 0":[0.6948754478509624,0.01653582367967438],"agent: brassbunny":[0.7287605194508434,0.02016896244023942],"agent: cloudwalk":[0.6996505041024527,0.05003454656156215],"agent: gbox":[0.8605750624115157,0.01660938121361133],"agent: igg-baseline":[2.299008349595016,0.01148903747272426],"agent: igg-interrogation":[-0.06081383577379497,0.013180944824312901],"agent: igg-interrogation_plus_sa":[1.0114792618550998,0.011804688222226882],"agent: igg-interrogation_plus_sa_plus_honest_persona":[1.9117510662994852,0.011679446504606296],"agent: igg-interrogation_plus_sa_plus_other_ai":[1.5756729238694982,0.011595932690155993],"agent: igg-simple_interrogation":[3.0311848139062207,0.011570719989063113],"agent: iswe":[0.9372771264899138,0.032762448018441935],"agent: iswe-openmodels":[0.8881229935527758,0.032966082353526854],"ai singapore sea-lion 2 8b":[0.021332541734043867,0.026815601499943394],"ai21 jamba 1.5 large":[-0.16315223810382143,0.09227697795910889],"ai21 jamba large":[0.3521715878738601,0.11215690964742352],"ai21 jurassic-2 grande":[0.6088368185594162,0.5050182894402542],"ai21 jurassic-2 jumbo":[0.15008052121922277,0.5048966736106064],"aidc-ai ovis1.5 gemma2 9b":[0.7404875405343597,0.05007507215240133],"aidc-ai ovis1.5 llama3 8b":[0.6133298072163291,0.0500057425596559],"aidc-ai ovis1.6 gemma2 27b":[0.8633188385205726,0.050164506996488015],"aidc-ai ovis1.6 gemma2 9b":[0.7704679225034006,0.05008602556971967],"aidc-ai ovis1.6 llama3.2 3b":[0.4728547389884106,0.049920077000714345],"aidc-ai ovis2 16b":[0.8878347296903812,0.05017324830295122],"aidc-ai ovis2 1b":[0.44810540872900506,0.049907424171040396],"aidc-ai ovis2 2b":[0.6962491171448021,0.05003514761553009],"aidc-ai ovis2 34b":[0.999262790136059,0.05027852711447245],"aidc-ai ovis2 4b":[0.8362891982413405,0.050135514707508544],"aidc-ai ovis2 8b":[0.8883753641273118,0.050178690763085634],"aki":[-0.07551072146657944,0.04978197002645682],"aleph alpha luminous base":[0.6456650520786333,0.5050419566991612],"aleph alpha luminous extended":[0.4916900840750037,0.5049724133682539],"aleph alpha luminous supreme":[0.22347951503790608,0.5049071542279041],"alibaba mplug-owl2":[-0.16305630593133438,0.04977803673144763],"alibaba mplug-owl3":[0.09854746693272551,0.06591892586922479],"alibaba ovis-u1":[0.039633848052170004,0.028248104967852482],"alibaba qwen 7b":[0.19449668674920254,0.033841519999528814],"alibaba qwen max":[0.19969489565546134,0.11208471301873052],"alibaba qwen plus":[0.5744678060467853,0.11233361938106674],"alibaba qwen turbo":[-0.25562534882787075,0.02513281229023382],"alibaba qwen-vl max":[0.5123575345685728,0.02562819342481459],"alibaba qwen-vl plus":[0.10043133482628326,0.02558161519786811],"alibaba qwen1.5 110b":[-0.08265412260112512,0.09228860770025885],"alibaba qwen1.5 14b":[-0.3490899433908075,0.09231775696819002],"alibaba qwen1.5 72b":[0.0003735053361533174,0.016558528157419376],"alibaba qwen1.5 7b":[-0.3554835565584551,0.03455818717903851],"alibaba qwen2 72b":[0.4352951010515305,0.0208167857253692],"alibaba qwen2-vl 2b":[0.32617440469063463,0.04986085656709409],"alibaba qwen2-vl 72b":[0.7153889868304443,0.03839625315485246],"alibaba qwen2-vl 7b":[0.612175919114359,0.0499799550424666],"alibaba qwen2.5 0.5b":[-1.3153046509078195,0.11328458198682641],"alibaba qwen2.5 32b":[0.6487641736088939,0.008849000231214732],"alibaba qwen2.5 72b":[0.12523324266124736,0.0044356880694985164],"alibaba qwen2.5 7b":[-0.04081717419029612,0.012101339268485469],"alibaba qwen2.5-coder 32b":[0.21136613403381913,0.024148571999266205],"alibaba qwen2.5-math 7b":[-0.16292859446991395,0.06595475976559059],"alibaba qwen2.5-vl 32b":[-0.27818043566371936,0.03860617597022786],"alibaba qwen2.5-vl 3b":[0.4236152262512929,0.021323380858259928],"alibaba qwen2.5-vl 72b":[0.7406569873454871,0.018326508058231786],"alibaba qwen2.5-vl 7b":[0.6034050522223606,0.021352360450464014],"alibaba qwen3 0.6b":[-1.7276930770230678,0.11473184561166283],"alibaba qwen3 14b":[0.7591191400967716,0.008158346774478346],"alibaba qwen3 235b":[-0.01208510318366814,0.027963808335955912],"alibaba qwen3 235b a22b":[0.5757413035994151,0.015511196164199971],"alibaba qwen3 235b a22b thinking":[0.6960892105678093,0.06122392917347333],"alibaba qwen3 30b a3b":[-0.07313673055175127,0.07591270803658474],"alibaba qwen3 32b":[-0.14289816036272407,0.11188349052927883],"alibaba qwen3 8b":[-0.17264969552752127,0.11206055759667108],"alibaba qwen3 max":[0.5682120358440362,0.05352574295113751],"alibaba qwen3-coder":[0.7144317961491989,0.0415691660357783],"alibaba qwen3-coder 30b":[0.44310786000989816,0.257085522412963],"alibaba qwen3-coder 480b":[-1.486179346092448e-17,0.04433859496556966],"alibaba qwen3-next 80b a3b":[0.23652205312066443,0.01956854361110734],"alibaba qwen3-vl 8b":[0.0019756338718447345,0.04651006334963067],"alibaba qwen3-vl plus":[0.6945546827552761,0.044438435480853355],"alibaba qwen3.5":[0.48121006746571293,0.029696576386164533],"alibaba qwen3.5 0.8b":[-1.1257891192933012,0.11789039527496858],"alibaba qwen3.5 122b a10b":[0.6860805978225306,0.03348014179200834],"alibaba qwen3.5 27b":[0.1790283653508254,0.1120777960424634],"alibaba qwen3.5 35b a3b":[0.28845909291606975,0.1007572901122836],"alibaba qwen3.5 397b a17b":[0.7627775892717698,0.019589388173456554],"alibaba qwen3.5 9b":[-0.11144734001144127,0.1120500298942378],"alibaba qwen3.5 flash":[0.2726506048997503,0.11211454665981088],"alibaba qwen3.5 plus":[0.6814552387925052,0.11245223504756553],"alibaba qwen3.6":[0.4683816380795082,0.024789477440329916],"alibaba qwen3.6 35b a3b":[0.49639204061343384,0.044937736468755735],"alibaba qwen3.6 max":[0.7472118358999542,0.1109609536016423],"alibaba qwen3.6 plus":[0.9178916011775621,0.031216216005662965],"alibaba qwen3.7 max":[0.7495644200831658,0.06448329001934987],"alibaba qwen3.7 plus":[0.777594334851719,0.11312347162313276],"alibaba qwq 32b":[0.14007577726516293,0.026959622068445436],"allenai molmo 72b":[0.3101747132615099,0.049855586345848364],"allenai molmo 7b-d":[0.5991418915091682,0.049983503561097334],"allenai molmo 7b-o":[0.07519623618974215,0.049801306706311534],"allenai molmoe 1b":[0.12113835000956968,0.049809172431230064],"allenai olmo 2 13b":[-0.4551014743881572,0.030318732154968074],"allenai olmo 2 32b":[-0.4338072382110456,0.03033711180012828],"allenai olmo 2 7b":[-0.7918422674368878,0.030171050231027997],"allenai olmo 3.1 32b":[-0.3103673174517787,0.11192993180006558],"allenai olmoe 1b-7b":[-0.9794249295144131,0.030189365557626368],"allenai tulu 65b":[-0.7717814557056906,0.01997966530530785],"allenai tulu 7b":[-0.953606651004552,0.03942275508630797],"amazon nova act":[0.9091035095992813,0.01499827163395321],"amazon nova micro":[-0.2419964521317314,0.11207946033311122],"amazon nova premier":[0.6421963359636264,0.11240598288139612],"amazon nova pro":[0.23807453903126632,0.02159035937364124],"ant bailing-mm":[0.6683550903915482,0.05003447836234967],"ant bailing-mm lite":[0.9253043352946259,0.050194895171076684],"ant bailing-mm pro":[0.9495765902600581,0.050225189923355625],"ant group ling 2.6 flash":[0.8188442427230519,0.11880843597885753],"anthropic claude 1":[-0.09047715870193221,0.5049134575520821],"anthropic claude 2":[0.35953301891354034,0.12282750884156121],"anthropic claude 3 haiku":[-0.21557979260174628,0.00978403194935997],"anthropic claude 3 opus":[0.13678089600570476,0.0044223245333554735],"anthropic claude 3 sonnet":[0.09458179048427368,0.009886542147696062],"anthropic claude 3.5 haiku":[0.35976734583575876,0.01639976515414661],"anthropic claude 3.5 sonnet":[0.8557614902952352,0.000244225973992831],"anthropic claude 3.7 sonnet":[0.6047879884678848,0.0014193638234251287],"anthropic claude fable 5":[1.540427589574205,0.023823086371964477],"anthropic claude haiku 4.5":[0.364625558889342,0.01278507083973921],"anthropic claude instant":[0.24122298764596706,0.5049046568056731],"anthropic claude opus":[0.4297329018666917,0.09230534035231514],"anthropic claude opus 4":[0.7209113643842511,0.00647992437395606],"anthropic claude opus 4.1":[0.5696990889032252,0.034130521849722636],"anthropic claude opus 4.5":[0.9698202115306475,0.009480755412242496],"anthropic claude opus 4.6":[0.45789101097750107,0.007339692523148264],"anthropic claude opus 4.7":[1.1424389814547375,0.008772451250412216],"anthropic claude opus 4.8":[1.398920477978904,0.018380028346009623],"anthropic claude opus 5":[1.9293219191954079,0.03423195159927941],"anthropic claude sonnet":[2.47789710577571,0.0010546578917204536],"anthropic claude sonnet 4":[0.43802700075209433,0.004848033349997896],"anthropic claude sonnet 4.5":[0.7873335776584586,0.0037345207600077363],"anthropic claude sonnet 4.6":[1.0140165591935315,0.010994632779201314],"anthropic claude sonnet 5":[0.9519929406508185,0.047307147687013516],"arx 3":[0.9686626967521611,0.04843294422466256],"baai aquila-vl 2b":[0.42906651334470064,0.04989739598136793],"baai emu2":[-0.304849693310596,0.04977431473902503],"baai emu3":[0.1488120200723231,0.04984309861644035],"baidu ernie 4.5 300b a47b":[0.21264815267135834,0.11208939120427983],"baidu ernie 4.5 turbo vl":[0.21575260583162598,0.11314645102463387],"baidu qianfan vl 70b":[0.18841381699449977,0.11312014349750069],"baidu qianfan vl 8b":[0.003743521535291702,0.1130288887019078],"biomistral 7b":[-0.8168420701925663,0.1159011623230522],"black forest labs flux":[5.194520291022282e-17,0.04564353086885974],"bunny llama 3 8b":[0.22153767440901154,0.049833096585502445],"bytedance bagel":[0.4742251259352787,0.0054023641089788466],"bytedance doubao 1.5 pro":[0.3874136521802195,0.005359288086562412],"bytedance doubao 1.5 thinking":[0.5695307624799121,0.004848400572640951],"bytedance doubao seed 1.6 vision":[0.48157457443139456,0.1132897848222867],"bytedance doubao vl":[-1.0718652376167448,0.0501171746147896],"bytedance seed 1.6":[0.469443362252227,0.11223899373115832],"bytedance seed 1.6 flash":[-0.06062910351292408,0.11204562677934077],"bytedance seed 2.0 lite":[0.8338447846766628,0.11266408597217548],"bytedance seed 2.0 mini":[0.5571295418556723,0.1123165563376669],"bytedance valley-eagle":[0.6883606792741622,0.050030046476354915],"cambrian 13b":[0.19032408147897117,0.049828435868025496],"cambrian 34b":[0.30961516797668315,0.04987137056452012],"cambrian 8b":[0.13808827474098617,0.04983344338979004],"chinese-llama-alpaca-2 7b":[-0.12170094960682276,0.7943897315204317],"chinese-llama-alpaca-3 8b":[-0.07731365814596584,0.7944206124880131],"cohere command":[0.13996321917398452,0.5049009349940627],"cohere command a":[0.36544548618911044,0.021286760251904877],"cohere command light":[0.6272223422237512,0.5050323543813136],"cohere command r":[-0.1547542841810233,0.004623574516561565],"cohere command r+":[-0.022959007578708106,0.017309453090330745],"cohere command r7b":[-0.3832884319692661,0.1121415257882779],"databricks dbrx":[-0.29941016469140647,0.0032874744339621764],"deepmind flamingo":[-0.8949857571759368,0.04989526027056049],"deepseek":[0.3344224450760204,0.09234858466482009],"deepseek coder 33b":[-0.1518867300469887,0.003973568896312782],"deepseek coder v2":[0.2694541790548874,0.09232440595143254],"deepseek janus 1.3b":[-0.20649303300974503,0.04977471117318169],"deepseek janus-pro 7b":[0.22556511602137694,0.04983553608245827],"deepseek llm 67b":[-0.031357272145511414,0.03099211008800429],"deepseek math 7b":[0.0,0.04920536165891988],"deepseek r1":[0.5463126630942994,0.0013272873139657494],"deepseek r1 distill llama 70b":[0.21204456725460122,0.11191500867840001],"deepseek r1 distill qwen 1.5b":[-1.0394355320263806,0.03433558657565174],"deepseek r1 distill qwen 32b":[-0.12926648858045725,0.1120525040771],"deepseek r1 distill qwen 7b":[-0.5113057181801803,0.03428687876136108],"deepseek v2.5":[0.3527945707298385,0.0922990798072821],"deepseek v3":[0.5116619789300774,0.0014376176749319812],"deepseek v3.1":[0.38810116671250855,0.08458113064647771],"deepseek v3.2":[0.6804103383370842,0.012814859051230174],"deepseek v4":[0.2030818993847565,0.026399498666273644],"deepseek v4 flash":[0.5927764240402679,0.020436881407068067],"deepseek v4 pro":[0.8327478996346569,0.009189203045247459],"deepseek vl 1.3b":[-0.3736294204908299,0.049796476758188005],"deepseek vl 7b":[-0.029248455658729595,0.04981070913255559],"deepseek vl2":[0.6101997559774357,0.049999887712716774],"deepseek vl2 small":[0.49477457436380246,0.049935950861083926],"deepseek vl2 tiny":[0.3800873924445685,0.0498821235811194],"defog sqlcoder 70b":[-0.20809255611002747,0.0036279490228516044],"defog sqlcoder 7b":[-0.3341837614867755,0.0036843618349519827],"eleutherai pythia 1.4b":[-1.060548507816178,0.0651991876704238],"eleutherai pythia 12b":[-0.9057688418865626,0.04254486723748615],"eleutherai pythia 160m":[-1.260906024408969,0.21608929828207013],"eleutherai pythia 1b":[-1.1486969396420044,0.08937505788184082],"eleutherai pythia 2.8b":[-0.9413287053680468,0.04644333422593668],"eleutherai pythia 410m":[-1.1991096318534151,0.11242158460778545],"eleutherai pythia 6.9b":[-0.9649753887202916,0.04938536594486039],"eleutherai pythia 70m":[-0.9742653579310673,0.5224424490013653],"fusion-in-decoder":[-0.24896768443495948,0.07322100662574074],"google gemini 1.0 pro":[0.14801177748123648,0.02617791514613482],"google gemini 1.5 flash":[0.3307379116463238,0.007812417367011953],"google gemini 1.5 pro":[0.24250421944507392,0.004000866165090298],"google gemini 2.0 flash":[0.40211840783277536,0.003952630514974937],"google gemini 2.0 flash-lite":[0.31759869005854446,0.013711606657619876],"google gemini 2.0 pro":[0.4903148666984641,0.0328575454095266],"google gemini 2.5 flash":[0.7760272978307995,0.004948269631560559],"google gemini 2.5 flash-lite":[0.4049740896375571,0.026311731932424125],"google gemini 2.5 pro":[0.712420575997365,0.0017416280341982042],"google gemini 3 flash":[0.6065084070740908,0.008109659656330773],"google gemini 3 pro":[1.036777533033559,0.005375680085389206],"google gemini 3.1 flash-lite":[0.7529954882720797,0.020516438018584784],"google gemini 3.1 pro":[1.234573861184926,0.005905245377186649],"google gemini 3.5 flash":[1.0652526083746856,0.022033402826309265],"google gemini flash":[0.12416040091607568,0.09228247939827068],"google gemini pro":[0.07767249348621728,0.018043698554666976],"google gemini pro vision":[0.3059448815122438,0.04986230581501017],"google gemini ultra":[0.4274031885908919,0.11623492356936585],"google gemma 2 27b":[0.059237728162265496,0.04339616631478175],"google gemma 2 2b":[-0.6360711774684352,0.11214216667320863],"google gemma 2 9b":[-0.4377021064467202,0.019567711245174993],"google gemma 2b":[-0.7038431696484185,0.019454362628111403],"google gemma 3 12b":[0.0548682755125312,0.013237787003230068],"google gemma 3 1b":[-1.1220483807205983,0.11283651629693175],"google gemma 3 270m":[-1.4768742171006313,0.11376047855118442],"google gemma 3 27b":[0.07604281768212574,0.006346146873035934],"google gemma 3 4b":[-0.15139354740429165,0.01088753862341923],"google gemma 3n e4b":[-0.5249630913747895,0.08491534008467652],"google gemma 4 26b":[-0.18733629522515724,0.1118919218090359],"google gemma 4 31b":[-0.11958137886614104,0.11188017403823493],"google gemma 7b":[-0.4860023411639247,0.014547943814211374],"google learnlm 1.5 pro":[0.22149745304201926,0.06795783896586212],"google med-palm 2":[0.15770838477980353,0.11611908826195645],"google medlm":[-0.029130315861611873,0.11606227802078506],"google paligemma 3b":[0.13604025276457343,0.04982011405941882],"google palm 2 bison":[-0.24900761536776092,0.504954800184693],"google palm 2 unicorn":[-0.3473878787425248,0.5049928418816061],"gustavosta magicprompt":[-0.8162865402926404,0.06071508759057064],"h2o.ai h2ovl mississippi 1b":[-0.19076513634483747,0.049775268618434725],"h2o.ai h2ovl mississippi 2b":[0.2410841084097577,0.049841041616505356],"hugging face idefics 80b":[-0.23132892483085996,0.0497786568932739],"hugging face idefics 9b":[-0.4489762793504776,0.04978467992671256],"hugging face idefics2 8b":[0.3014151907522119,0.04985653503671783],"hugging face idefics3 8b":[0.4385591582742164,0.04990510851539875],"hugging face smollm 135m":[-0.6802595702459899,0.06203012389080979],"huggingface smollm2 1.7b":[-0.7118034603757658,0.11221729718308313],"huggingface smollm2 135m":[-1.6088626233717394,0.11424108251439061],"huggingface smollm2 360m":[-0.7454493098841317,0.11225890486666878],"huggingface smolvlm":[0.016622479464794605,0.017169645034129773],"huggingface smolvlm 256m":[-0.3742657105123663,0.04977750583218328],"huggingface smolvlm 500m":[-0.08157426475037567,0.04978428121446086],"huggingface smolvlm2":[0.2566475947069112,0.049840762406940235],"huggingface smolvlm2 256m":[-0.5046072969869967,0.04978944228324653],"huggingface smolvlm2 500m":[-0.13405573157573625,0.04978067355343712],"iask pro":[0.9846187615878818,0.09240911709176054],"ibm granite 3.3 2b":[-0.7173173741813171,0.11222318673511067],"ibm granite 3.3 8b":[-0.1075185468462359,0.030812133067333453],"ibm granite 4.0 h-small":[0.1997210059136972,0.01615559610358951],"ibm granite 4.0 micro":[-0.3202838405725442,0.015468507134237254],"internlm-xcomposer":[-0.048621147185188354,0.049785229955976534],"internlm-xcomposer2":[0.5770463885814453,0.025627425629732067],"internlm-xcomposer2 1.8b":[0.25203235815834907,0.04984363404774381],"internlm-xcomposer2.5":[0.590101642343346,0.049986698176072805],"jt-vl":[0.9005348399510773,0.050195852630662],"kiss-1":[0.8280055200860209,0.01655092425007659],"llama-3-8b-instruct axiomatic dsep (lora)":[0.41756914359089864,0.039499997178528125],"llama-3.1-8b-instruct + shared e2e direct i/o (10-shot)":[-0.45446056882544456,0.04575592615738615],"llama-3.1-8b-instruct-cdg":[-0.40179056242303424,0.023488475606274144],"llama-3.2-1b-instruct-grpo":[-0.08317611260848437,0.08763579867483337],"llama-3.2-1b-instruct-grpo-001":[-0.08143097159204525,0.08763637453254448],"llama-3.2-1b-instruct-grpo-002":[0.03934713856422905,0.08811432712768123],"llama-3.2-1b-instruct-grpo-003":[0.12432689683687043,0.08773104642678407],"llama-3.2-1b-instruct-grpo-004-step-0050":[-0.3705811360508788,0.087589130151512],"llama-3.2-1b-instruct-grpo-005-step-1000":[0.15840360447346302,0.08775214156026058],"llava internlm 7b":[-0.1300579686782595,0.04978244720704726],"llava internlm2 20b":[0.004849051314188914,0.04980723061281693],"llava internlm2 7b":[-0.028840846341958548,0.04979933594610978],"llava llama 3 8b":[0.1351815190442767,0.04982979364973734],"llava vicuna 7b":[-0.5761988182281498,0.04979872942895045],"llava-1.5 vicuna 13b":[-0.0878532984010506,0.025531658923798325],"llava-1.5 vicuna 7b":[-0.19298536441330003,0.02552517013719556],"llava-cot 11b":[0.10390715113919827,0.04981014584817898],"llava-next llama 3 8b":[0.09659187692667087,0.04986762004275842],"llava-next mistral 7b":[-0.10730714127615146,0.049885313510706304],"llava-next qwen 32b":[0.1328806050391744,0.049855444525699975],"llava-next vicuna 13b":[0.050142848705517835,0.04987185233501166],"llava-next vicuna 7b":[-0.07715904164457699,0.049841171802040965],"llava-next yi 34b":[0.2151987634541888,0.04995178870830159],"llava-next-interleave qwen 7b":[0.2721338934573077,0.02556607386119093],"llava-onevision qwen2 0.5b":[-0.14281582790336045,0.02552537780032818],"llava-onevision qwen2 72b":[0.8081162197906562,0.025701152124006747],"llava-onevision qwen2 7b":[0.5858455970557553,0.025644911871163155],"lmsys vicuna 13b":[2.031344378515548,0.17693323212688225],"lmsys vicuna 7b":[-0.7589395749051074,0.017251561140838118],"long_context-counterfactual_igg-baseline":[2.0827042901797554,0.011474308362807748],"long_context-counterfactual_igg-baseline_2":[2.98099895987197,0.011533503419654659],"long_context-counterfactual_igg-baseline_3":[1.9357121128258121,0.011481930046728076],"long_context-counterfactual_igg-hinge_length_penalty":[1.739026583103603,0.022707071693338916],"long_context-counterfactual_igg-scratchpad_monitor":[-1.3555134165014828,0.060705653569212634],"long_context-counterfactual_tgg-baseline":[2.3856708843852963,0.011481672545103074],"long_context-counterfactual_tgg-baseline_2":[2.5338974291949534,0.011488466685455103],"long_context-counterfactual_tgg-baseline_3":[2.454524704559146,0.011491095565310649],"long_context-counterfactual_tgg-hinge_length_penalty":[1.1105655888952082,0.022993200654452355],"long_context-counterfactual_tgg-scratchpad_monitor":[-1.1359500026249338,0.06259333874090751],"long_context-emotional_igg-baseline":[3.758767621971408,0.01167959941518657],"long_context-emotional_igg-baseline_2":[2.3951643611941593,0.011482397424207938],"long_context-emotional_igg-baseline_3":[3.449156401825044,0.01160433953043535],"long_context-emotional_tgg-baseline":[2.291253771241873,0.01147547214763228],"long_context-emotional_tgg-baseline_2":[2.7299784457593477,0.011501036701939105],"long_context-emotional_tgg-baseline_3":[2.914351614726054,0.011522602936297314],"long_context-igg-baseline":[2.6285287662517214,0.011493095221529588],"long_context-igg-baseline_2":[2.5032285470125153,0.011494629013919061],"long_context-igg-baseline_3":[2.2254383598043157,0.011476265630505317],"long_context-igg-hinge_length_penalty":[1.3472271546555241,0.022831809334971098],"long_context-igg-output_only":[2.7025761462107956,0.011497917828614033],"long_context-igg-output_only_2":[2.585785067743976,0.011491859343158729],"long_context-igg-output_only_3":[2.652391419783291,0.011496555464730133],"long_context-igg-reward_af":[4.145816626810319,0.023534631973426888],"long_context-igg-scratchpad_monitor":[-1.2500742067730455,0.055029349834163604],"long_context-igg-scratchpad_monitor_2":[-1.0845800629296598,0.05882875613855437],"long_context-igg-scratchpad_only":[2.27338713522619,0.011476854813138157],"long_context-igg-scratchpad_only_2":[2.434273600408107,0.011498881696448011],"long_context-igg-scratchpad_only_3":[2.967002319558314,0.011529976454321418],"long_context-short_igg-baseline":[2.401953063432315,0.011482794332927346],"long_context-short_igg-baseline_2":[2.819278966755045,0.011526678718526999],"long_context-short_igg-baseline_3":[2.8996965809977815,0.011523512577481833],"long_context-short_igg-hinge_length_penalty":[0.8887670772119911,0.023604246631791066],"long_context-short_tgg-baseline":[2.2887770710017934,0.011475695661074222],"long_context-short_tgg-baseline_2":[1.6473682197448694,0.011488898074802934],"long_context-short_tgg-baseline_3":[1.8475665316833585,0.011476078830274091],"long_context-short_tgg-hinge_length_penalty":[-0.12324685455139504,0.024394756703274355],"long_context-sl3_helpful-baseline":[-7.281022799449156,0.12678294001460363],"long_context-tgg-baseline":[2.4030567594727565,0.01147956153643701],"long_context-tgg-baseline_2":[1.9480466622808632,0.011476775096510352],"long_context-tgg-baseline_3":[2.5055358122984948,0.011484771457898653],"long_context-tgg-baseline_4":[2.633445623519898,0.011493390357701708],"long_context-tgg-hinge_length_penalty":[1.305762449214908,0.022815865547127733],"long_context-tgg-output_only":[1.894912984228716,0.011475760929272808],"long_context-tgg-output_only_2":[2.102841225147847,0.011473328565194662],"long_context-tgg-output_only_3":[2.101065422177716,0.011473389857066528],"long_context-tgg-reward_af":[2.9680049852823385,0.02284400402480663],"long_context-tgg-scratchpad_monitor":[-1.1338078028355667,0.0584035578735496],"long_context-tgg-scratchpad_only":[3.3092492110472955,0.011606401595086252],"long_context-tgg-scratchpad_only_2":[3.2342313165873087,0.011571795002145325],"long_context-tgg-scratchpad_only_3":[2.51011976692578,0.011500786861350743],"long_context-training_sycophancy-baseline":[0.11424750799626791,0.011772972333302946],"long_context-training_sycophancy-baseline_2":[-2.5094453763021365,0.014721379175202338],"long_context-training_sycophancy-baseline_3":[-1.9564197128189171,0.013409845054566983],"magellanes":[0.5903098654950758,0.024809383979537428],"maritaca sabiazinho-3":[0.22236693220827702,0.08779623457139393],"maritaca sabi\u00e1-3":[0.09446539325262407,0.08771388147193987],"meta chameleon 30b":[-0.6441630550552886,0.04989296195381241],"meta chameleon 7b":[-0.7407630425756809,0.04986925502318931],"meta code llama 13b":[-0.45843744761152594,0.018021091961815013],"meta code llama 34b":[-0.449589662489786,0.0031494679041705552],"meta code llama 70b":[-0.33503030539088124,0.0036860705276622018],"meta cwm":[0.1138684701159209,0.42568251445078586],"meta llama":[-0.1623178020266296,0.19687249774154336],"meta llama 2 13b":[-1.1586134486030626,0.018451247594899578],"meta llama 2 70b":[-1.143631201412329,0.005713686953173052],"meta llama 2 7b":[-1.0143513513441513,0.01505652864916312],"meta llama 3 70b":[0.08222454088131755,0.002069999150347952],"meta llama 3 8b":[-0.3244471226563596,0.0025385898788562126],"meta llama 3.1 405b":[0.37281856408071595,0.008464790735806657],"meta llama 3.1 70b":[0.11610816538346518,0.0029710678232825706],"meta llama 3.1 8b":[-0.4340083318699939,0.0020455712704993234],"meta llama 3.2 11b":[-0.10265973584076561,0.04989009014586898],"meta llama 3.2 1b":[-1.5861271360336129,0.05260284691643875],"meta llama 3.2 3b":[-0.35364725078063475,0.051752227088678604],"meta llama 3.2 90b":[-0.13245660559103126,0.04432482292923514],"meta llama 3.3 70b":[0.12013653396023997,0.004301652943671185],"meta llama 4 maverick":[0.33252111592664896,0.0026845238336410627],"meta llama 4 scout":[0.12405693183569015,0.005592627582684116],"meta llama 65b":[0.5331397385291611,0.5049887800818385],"microsoft bing chat":[0.13682952025647926,0.07339208231174173],"microsoft kosmos-2":[-0.9286719567954661,0.04990176679078892],"microsoft phi-3 medium":[0.14923323229831129,0.005195772645869598],"microsoft phi-3 mini":[-0.42446985751961924,0.016381625966402677],"microsoft phi-3 vision":[0.4466672458716103,0.04992164784241222],"microsoft phi-3.5 mini":[-0.3041211640643011,0.04089070414994996],"microsoft phi-3.5 vision":[0.3145479683449894,0.04225264047028745],"microsoft phi-4":[-0.2556401556173851,0.11191033380807516],"microsoft phi-4 vision":[0.5327094300343774,0.050002099577103956],"microsoft wizardcoder 33b":[-0.1924066190572182,0.0036229021016158857],"mini-monkey":[0.38096364835671664,0.049883294906358046],"minigpt-4 13b":[-1.455897527713941,0.050245721895263204],"minigpt-4 7b":[-1.3273940099708434,0.05011771703748297],"minigpt-v2":[-1.1673366666104243,0.05000847715637733],"minimax abab6.5s":[-0.7909208958586091,0.04999989326003566],"minimax abab7":[0.6762893896669641,0.050025719899037],"minimax m1":[-0.12649538805755828,0.11215785593017193],"minimax m2":[0.02193629226891211,0.4256423437017283],"minimax m2.1":[0.19459863314093273,0.4257491708770943],"minimax m2.5":[1.0126582108015258,0.016430602996576667],"minimax m2.7":[0.2138925902493361,0.06236115980054565],"minimax m3":[0.7311440126288952,0.05800595706330403],"mistral 7b":[-0.6344670296713426,0.0011049999582053384],"mistral codestral":[0.36102972227604935,0.02373236550477241],"mistral codestral mamba":[-0.9046969001949837,0.06283516232627648],"mistral devstral medium":[0.011567223340012388,0.25737223001034043],"mistral devstral small":[-0.1958507860492232,0.2577602012744165],"mistral large":[0.02930513462928326,0.0626438077598964],"mistral large 3":[0.31891069092997687,0.11318062793852932],"mistral magistral medium":[0.19857476889919004,0.11791732664656403],"mistral mathstral 7b":[-0.3970291493403681,0.09228096660840787],"mistral medium 3":[0.3911783172246702,0.01249071140686758],"mistral ministral 3b":[-0.38594843637672194,0.11214300582669028],"mistral ministral 8b":[-0.06824552382881555,0.11204603692194627],"mistral mixtral 8x22b":[0.1127745606294711,0.006892138216880864],"mistral mixtral 8x7b":[-0.3850492738824969,0.0014260473927925797],"mistral nemo 12b":[-0.2746121790205197,0.11191663474836269],"mistral pixtral 12b":[0.04156578645040952,0.04980555236991798],"mistral small 24b":[-0.06607712719788449,0.11187542739014257],"mistral small 3.2 24b":[0.245567833761004,0.2571323972989089],"mistral small 4":[-0.09865013134580602,0.029598357120468318],"mmalaya":[-0.5914276648171166,0.04981625951902275],"mmalaya2":[0.6295060501346771,0.04999323038281371],"monkey":[0.12278628048202178,0.025542202875453154],"moondream 1":[-0.29793349294611404,0.049774419476780185],"moondream 2":[-0.052559811894740835,0.049784313777904675],"moonshot kimi k2":[0.5078035736154741,0.017114994614690904],"moonshot kimi k2.5":[0.8712356709508936,0.11152132210151214],"moonshot kimi k2.6":[0.8092209011503878,0.01031394929010587],"moonshot kimi k2.7":[0.8777851922362295,0.11331272909165406],"moonshot kimi k3":[1.1537284910955352,0.098766752577596],"moonshot kimi-dev 72b":[-0.44204466969632467,0.25845473655463347],"moonshot v1":[0.5659191250506784,0.049982314874509146],"mug-u 7b":[0.9510237754839262,0.05026476749175494],"ncsoft varco-vision":[0.5176471838717683,0.0500275386155569],"nex n1":[-0.41449370208937,0.11197947821533819],"nous research hermes 3 405b":[-0.18733629522515724,0.1118919218090359],"nous research hermes 4 405b":[0.01987659083326352,0.11187612003792924],"nvidia eagle x5 13b":[0.4035955384587589,0.0499033376515635],"nvidia eagle x5 34b":[0.3866736995734407,0.0499646516867665],"nvidia eagle x5 7b":[0.3053913627711177,0.049863400278897595],"nvidia nemotron 3 nano 30b":[-0.18499217422966474,0.1118914075937437],"nvidia nemotron 3 super 120b":[0.33709602657783116,0.11196890708483508],"nvidia nemotron 3 ultra":[0.7172773939282252,0.10271610793500036],"nvidia nemotron 70b":[0.12014336786120958,0.11188991227679292],"nvidia nemotron nano 9b v2":[-0.5782865837412887,0.11209180035910545],"nvidia nemotron orchestrator 8b":[0.8443983328850717,0.025321153109568104],"nvidia nemotron super 49b":[-0.15457339437485593,0.11188543696947931],"nvidia nvlm":[0.16269554044058354,0.0498497239107795],"nvidia vila 1.5 13b":[0.24074783307188016,0.049837769752878625],"nvidia vila 1.5 3b":[-0.09626251427828277,0.04978142747434227],"nvidia vila 1.5 40b":[0.4167842281058156,0.04991137460871237],"nvidia vila 1.5 8b":[-0.116731112858138,0.049778979604054995],"ola":[0.7466853907445503,0.05011116469418424],"omchat":[0.535249443198034,0.04994196994494023],"openai cua":[0.02283381725059318,0.023576768474104195],"openai gpt-2":[-0.32843503087562514,0.02820938369289781],"openai gpt-3.5":[-0.2514090078528126,0.0019441642517272792],"openai gpt-3.5 davinci":[-0.3983678965669471,0.06400606958019933],"openai gpt-3.5 turbo":[0.3677993432273866,0.02087837152424105],"openai gpt-4":[0.24582704357261542,0.0012043875876704307],"openai gpt-4.1":[0.5238049129461542,0.0017112924177495536],"openai gpt-4.1 mini":[0.3848718635252185,0.006182376124629196],"openai gpt-4.1 nano":[0.005119847006547,0.009677212954436737],"openai gpt-4.5":[0.45567268506662245,0.016481168218087653],"openai gpt-4o":[0.4358676411975979,0.0006773460091726094],"openai gpt-4o mini":[0.1376768661754868,0.001960613496534297],"openai gpt-4v":[0.08993787319104272,0.008287782401810533],"openai gpt-5":[0.895838759731396,0.0025702473935143993],"openai gpt-5 mini":[0.7455188642962278,0.006190029918734951],"openai gpt-5 nano":[0.5472777767516792,0.011214532622485876],"openai gpt-5 pro":[0.7063713019653756,0.021100279945000362],"openai gpt-5.1":[0.40428725011367955,0.008939605890399417],"openai gpt-5.2":[0.8243040586089839,0.004156257376605157],"openai gpt-5.2 pro":[0.5862585925380466,0.11214959721609703],"openai gpt-5.3":[0.7338812330402766,0.11231166757381753],"openai gpt-5.4":[1.0515783173549473,0.0060992661976280605],"openai gpt-5.4 mini":[0.43544442838936237,0.015802576071427533],"openai gpt-5.4 nano":[-0.012947913679047606,0.023931119771282115],"openai gpt-5.4 pro":[0.9720425216030556,0.11266190549633329],"openai gpt-5.5":[1.4380860785810494,0.006000823747823516],"openai gpt-5.5 pro":[1.2575751172369911,0.11328458198682641],"openai gpt-5.6 luna":[0.6485029336774663,0.11534400462723728],"openai gpt-5.6 sol":[1.1537284910955352,0.098766752577596],"openai gpt-5.6 terra":[0.6485029336774663,0.11534400462723728],"openai gpt-oss 120b":[0.7573822791009689,0.012696843086809023],"openai gpt-oss 20b":[0.4414948757581471,0.02548494912925805],"openai o1":[0.5957209904621148,0.0023799285302668572],"openai o1-mini":[0.38639493484410414,0.011191347320134026],"openai o3":[0.707039508923113,0.0032121643045488284],"openai o3-mini":[0.5996419537519871,0.002143381150586724],"openai o4-mini":[0.7574067287692366,0.00205204032331763],"openbmb minicpm-o 2.6":[0.7991093357346045,0.05012673867978796],"openbmb minicpm-v":[-0.0722188938474041,0.049782575123818625],"openbmb minicpm-v 2":[0.05481188840384665,0.049798182468423706],"openbmb minicpm-v 2.5":[0.4754700576052986,0.049925575553959226],"openbmb minicpm-v 2.6":[0.6197905668546853,0.05000091741002266],"openbmb omnilmm 12b":[0.04447612942890374,0.049796662039244176],"opengvlab internvl 1.1":[0.1528077443066677,0.04983542062272292],"opengvlab internvl 1.2":[0.4873190568071701,0.025603478547400253],"opengvlab internvl 1.5":[0.6063505931576643,0.04998286425745921],"opengvlab internvl2 1b":[0.07311533445350868,0.049801399686511205],"opengvlab internvl2 26b":[0.7767774296561166,0.05009017213202715],"opengvlab internvl2 2b":[0.3512674683233159,0.049873361745664674],"opengvlab internvl2 40b":[0.9108673530314336,0.05019479942967372],"opengvlab internvl2 4b":[0.5181952767233565,0.049942213198374025],"opengvlab internvl2 76b":[0.9446317876493239,0.050228506569308974],"opengvlab internvl2 8b":[0.6914509337771846,0.016237167061075555],"opengvlab internvl2.5 1b":[0.20572513884624544,0.025551495147260794],"opengvlab internvl2.5 26b":[0.894540393280978,0.02572679975785839],"opengvlab internvl2.5 2b":[0.40927131105048753,0.025582473239652508],"opengvlab internvl2.5 38b":[0.9998958405992203,0.02577310548989199],"opengvlab internvl2.5 4b":[0.6486561298679706,0.025640513171913275],"opengvlab internvl2.5 78b":[1.0684559831406568,0.025813703691985834],"opengvlab internvl2.5 8b":[0.797615367669916,0.02568932325705725],"opengvlab mini-internvl 2b v1.5":[0.2492592366430322,0.04983913485618747],"opengvlab mini-internvl 4b v1.5":[0.4783792925830658,0.049919285980410205],"openthaigpt 1.0.0 13b":[-0.2633155955977955,0.05242383511134797],"openthaigpt 1.0.0 7b":[-0.41926664667703717,0.05267257300454971],"pandagpt 13b":[-0.5945037921666048,0.049801584312791726],"parrot":[0.0014321934200730944,0.04979056913670488],"poolside laguna xs.2":[0.15995593281549808,0.4257169559927726],"prime intellect intellect-3":[0.13889941079038737,0.11189405789724946],"qihoo 360vl 70b":[0.2385006998319416,0.049845786213313585],"qwen_base":[-0.6354370092612996,0.056797183967866725],"qwen_chat":[0.0015393169841090213,0.04979101989488924],"rbdash 72b":[0.7665804903430413,0.05009306874863581],"reka edge":[-0.062210775949894624,0.049784324935577155],"reka flash":[0.05814578434442567,0.0497981835189238],"rhymes ai aria":[0.6350933723140515,0.05001382650951632],"ristretto 3b":[0.7548892992731692,0.050077343040919056],"ross-qwen2 7b":[0.47889202783025475,0.049936961773201],"saama openbiollm 70b":[-0.13617190420806782,0.11575876608653883],"saama openbiollm 8b":[-0.74167699485876,0.1157330841009265],"sail-vl 2b":[0.5126813413117987,0.0499323787613267],"sailor 14b":[0.015014549710727094,0.052221227794831473],"sailor 7b":[-0.2285593391043816,0.05238257026095354],"salesforce instructblip":[0.6155518066710635,0.02127306228739198],"salesforce instructblip 13b":[-0.5647263074104844,0.04983481941691389],"salesforce instructblip 7b":[-0.4470334180009422,0.049823586453032254],"salesforce xgen-mm":[0.3014351595715933,0.02556711117461582],"sambanova sambalingo thai 70b":[0.063128019714681,0.05221426745039015],"sambanova sambalingo thai 7b":[-0.3578109366854438,0.05256155149384992],"scb10x typhoon 1.5 72b":[0.2607676074942371,0.05226958442962309],"scb10x typhoon 1.5 8b":[-0.013150532974260488,0.05222901311850481],"scb10x typhoon 1.5x 70b":[0.32291359220972166,0.052315631868335974],"scb10x typhoon 1.5x 8b":[0.019030702835176123,0.052220341512048504],"scb10x typhoon 7b":[-0.15227988605467127,0.05230860575936679],"sea-lion 7b":[-0.7265682966847075,0.05353913273881393],"seallm 7b v2":[-0.2765087710011708,0.052440785002850106],"seallm 7b v2.5":[-0.009120662125441392,0.05222773034910443],"sensetime sensechat vision":[0.9620839104596932,0.050243730072312025],"sharecaptioner":[-0.1315992596165596,0.04977895240779795],"sharegpt4v 13b":[-0.05061989995125415,0.04979040405147576],"sharegpt4v 7b":[-0.12171027954139284,0.04978202033088419],"slime 13b":[-0.1444287045967722,0.04984474828273857],"slime 7b":[-0.11289147082958446,0.04979958069489418],"slime 8b":[0.07679371530561828,0.04981250001178553],"socraticlm":[-0.08782795094556439,0.06624481004306744],"stability ai stable diffusion 3 large":[5.194520291022282e-17,0.04564353086885974],"stability ai stable diffusion 3 medium":[5.194520291022282e-17,0.04564353086885974],"stability ai stable diffusion 3.5 large":[5.194520291022282e-17,0.04564353086885974],"stability ai stable diffusion 3.5 medium":[5.194520291022282e-17,0.04564353086885974],"stanford alpaca 13b":[-1.7758589019880617,0.024709699980568985],"stanford alpaca 7b":[-1.7823816244149127,0.02455026912376098],"stanford marin 8b":[-0.34132036132548005,0.030432322639332238],"stepfun step 3.5 flash":[0.5308399406443368,0.11211821561305324],"stepfun step 3.7 flash":[0.746711397847142,0.1130710066392008],"stepfun step-1.5v mini":[0.6280414509041857,0.04999584997938387],"stepfun step-1o":[0.9890215312858335,0.050294735641792085],"stepfun step-1v":[0.9316825730432277,0.050220342461174454],"stepfun step1x-edit":[-0.07610624683429326,0.03241787800256117],"sup-ai-ensemble":[1.2891945649118663,0.05294028461874839],"taiyi":[1.1268222400941301,0.05044438835049994],"telemm":[1.035944342094441,0.05030892331502987],"tencent hunyuan 3":[0.8237239163143248,0.11242659599118587],"tencent hunyuan a13b":[-0.5372803091947598,0.11205955265328901],"tencent hunyuan standard vision":[1.3557572550468422,0.05090358314924645],"tencent hunyuan vision":[0.2860381133218709,0.0498500913519435],"tencent points qwen2.5 7b":[0.5999397332342208,0.049985933952978095],"tencent points yi 1.5 9b":[0.5583904279482832,0.049954701546238746],"tencent points1.5 qwen2.5 7b":[0.6519693034583931,0.0500063603141763],"test":[-0.20330514622925305,0.03329291441151808],"tgg-baseline":[1.935431057475126,0.011474638618731497],"tgg-baseline_2":[2.9429969446920072,0.011531828690363165],"tgg-baseline_3":[2.021041823449479,0.011473959461651626],"tgg-baseline_4":[2.070863551083419,0.011473048237516945],"tgg-interrogation":[-0.40138685377965794,0.013655201978001979],"tgg-interrogation_plus_sa":[1.0451218322023412,0.01179931499983083],"tgg-interrogation_plus_sa_plus_honest_persona":[1.8090851302095847,0.011671581254383608],"tgg-interrogation_plus_sa_plus_other_ai":[2.281961392392733,0.011837978013784639],"tgg-interrogation_plus_sa_plus_sonnet_4":[0.31777092799022205,0.02150005114068102],"tgg-simple_interrogation":[2.5975100043786985,0.011821697896101883],"thinking machines inkling":[0.30070411350608384,0.13740270826571663],"tiger-lab mantis 8b clip-llama3":[-0.1172248339338585,0.0497791844473293],"tiger-lab mantis 8b fuyu":[-0.32134598035176476,0.04977502925122483],"tiger-lab mantis 8b idefics2":[0.16964027853181302,0.049820223781380776],"tiger-lab mantis 8b siglip-llama3":[-0.010974292854520293,0.04978893764809721],"tii falcon 2 vlm 11b":[0.4134829040139371,0.04991197030787583],"tii falcon 40b":[0.3760753219726851,0.504935730757031],"tii falcon 7b":[0.8855425466385335,0.5051997655583798],"tinyllama 1.1b cpt openwebmath":[3.042569680363008e-08,0.022658860060016276],"transcore-m":[-0.00666638581255232,0.049800318937725546],"update eval":[0.44577880386689117,0.023062972535873957],"vintern 1b":[0.003924443264224681,0.04979784528152316],"vintern 3b":[0.30834579633114395,0.049856778758140374],"vita":[0.4456112079596372,0.025592011446067518],"vivo bluelm-v":[0.7210107287316594,0.050085086334956105],"vxverse":[0.06284055001905312,0.04982550036480398],"wemm":[0.5380703724919536,0.04994357566315464],"writer palmyra fin":[0.3856380181646131,0.03282221999667358],"writer palmyra med":[-0.2240610573905486,0.030594401919336288],"writer palmyra x 004":[0.5014090588580209,0.033731304631884354],"writer palmyra x v2":[-0.2928808452614747,0.5049705768647932],"writer palmyra x v3":[-0.7095606227255531,0.5052192229221831],"writer palmyra x5":[0.4357233100652181,0.033185883988657516],"xai grok 2":[0.12960222384916373,0.017537179009919582],"xai grok 3":[0.3970349859664259,0.007965720753362736],"xai grok 3 mini":[0.3610485144168376,0.013735865043306974],"xai grok 4":[0.7609864334814118,0.009206277829970388],"xai grok 4 fast":[0.5006697408037533,0.2570982913969633],"xai grok 4.20":[1.0271139076605431,0.03134955734108055],"xai grok 4.3":[0.07243687170114312,0.15995287766311253],"xai grok code fast 1":[0.45132705155197544,0.25708661547802125],"xiaomi mimo v2 flash":[0.4565612003747265,0.11204276359649094],"xiaomi mimo v2 pro":[0.39509799782981886,0.11200194549304239],"xiaomi mimo v2.5":[0.6296307896629266,0.11219195646654846],"xiaomi mimo v2.5 pro":[0.828619565590241,0.11243353883733442],"xinyuan-vl 2b":[0.2999960091125565,0.04986649842878277],"zhipu cogvlm":[0.042084547081668096,0.04979725074501672],"zhipu cogvlm2":[0.33871452689816683,0.04986806025168711],"zhipu glm-4 32b":[0.10717158576086129,0.11205892394295831],"zhipu glm-4.5":[0.7105025596181925,0.03192107413001107],"zhipu glm-4.5 air":[0.6881455628315638,0.029136848639563007],"zhipu glm-4.6":[0.6765293707632459,0.018232513030267503],"zhipu glm-4.6v":[0.5689282854609508,0.06007251825094263],"zhipu glm-4.7":[0.7441288290765911,0.11232103897451683],"zhipu glm-4.7 flash":[0.085077489052378,0.11188349052927883],"zhipu glm-4v":[0.45127682006791187,0.04990736916903061],"zhipu glm-4v 9b":[-0.11148893499751143,0.04978528675768797],"zhipu glm-4v plus":[0.4373055024022699,0.025597547299843048],"zhipu glm-5":[0.91753043984035,0.01144959425228286],"zhipu glm-5 turbo":[0.8911800726899908,0.11275817265175768],"zhipu glm-5.1":[0.9656903009484697,0.005999824405268289],"zhipu glm-5.2":[1.0176113467991323,0.04067252837649257],"zhipu visualglm 6b":[-0.85518273708995,0.04989568787974972]},"version":2}'''


import threading  # noqa: E402

_STATE = json.loads(_STATE_JSON)
_MODELL = Modell(_STATE)
_RUECKFALL = float(_STATE.get("rueckfall", 0.5))
_CLIP = float(_STATE.get("clip", 1e-4))
_BB = _STATE.get("baselines") or {}
_BB_ALPHA = float(_BB.get("beta_alpha", 1.0))
_BB_BETA = float(_BB.get("beta_beta", 1.0))
_SPERRE = threading.Lock()  # the model keeps lazy caches; serialise calls if the platform uses threads
# Fallback counters (diagnostics for local tests only; never part of any prediction):
#   hier = hierarchical model answered; beta_binomial = stage 2 (smoothed own mean); konstant = stage 3 (constant)
_ZAEHLER = {"aufrufe": 0, "hier": 0, "beta_binomial": 0, "konstant": 0}


def _klemme(p):
    return min(max(float(p), _CLIP), 1.0 - _CLIP)


def _beta_binomial(input, labeled):
    """Stage 2: (alpha + k) / (alpha + beta + n) from the target pair's own labels (same 8 subject fields, same
    benchmark_id), O(|labeled|); tolerant of malformed entries (skipped)."""
    subject, item = input
    bid = (item.get("benchmark_id") or "") if isinstance(item, dict) else ""
    kf = konfig(subject) if isinstance(subject, dict) else None
    k = n = 0.0
    for e in labeled or []:
        try:
            (s, it), lab = e
            if not isinstance(s, dict) or not isinstance(it, dict):
                continue
            if (it.get("benchmark_id") or "") != bid or konfig(s) != kf:
                continue
            y = label_wert(lab)
            if y is None:
                continue
            k += y
            n += 1.0
        except Exception:
            continue
    return (_BB_ALPHA + k) / (_BB_ALPHA + _BB_BETA + n)


def predict(input, labeled=None):
    """Predict P(response == 1) for input = [subject, item]; labeled = [[[subject, item], label], ...].
    Never raises; always returns a finite float in [_CLIP, 1 - _CLIP]."""
    try:
        with _SPERRE:
            _ZAEHLER["aufrufe"] += 1
            p = _MODELL.wahrscheinlichkeit(input, labeled or [])
            if isinstance(p, float) and p == p and 0.0 <= p <= 1.0:
                _ZAEHLER["hier"] += 1
                return _klemme(p)
    except Exception:  # never let one odd input fail the whole evaluation (failure code 40)
        pass
    try:
        p = float(_beta_binomial(input, labeled))
        if p == p and 0.0 <= p <= 1.0:
            with _SPERRE:
                _ZAEHLER["beta_binomial"] += 1
            return _klemme(p)
    except Exception:
        pass
    try:
        with _SPERRE:
            _ZAEHLER["konstant"] += 1
    except Exception:
        pass
    return _RUECKFALL


def diagnose():
    """Copy of the fallback counters (local tests only)."""
    with _SPERRE:
        return dict(_ZAEHLER)
