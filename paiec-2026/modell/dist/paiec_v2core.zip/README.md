# Hierarchical logistic pair-level predictor (PAIEC 2026)

`model.py` is self-contained: Python standard library only, no network, no LLM, no files read at runtime. The fitted
state (subject abilities, metadata regression, hyperparameters, recalibration) is embedded as JSON text.

## Method in one paragraph

For a subject s on a benchmark b, the success rate is modelled as `logit r_sb = c_b + a_b * m_s + v_sb`. `m_s` is the
subject's ability, learned on the public measurement-db release (revision 54074453, 156 graded binary public
benchmarks) and looked up by `normalized_name`; unseen names get a ridge regression on visible metadata (provider,
release date, name tokens, parameter count parsed from the name). The benchmark location `c_b` and slope `a_b` are
unknown for a held-out benchmark; their Laplace posterior is computed from the revealed labels of all subjects of that
benchmark in `labeled` (grouped by the anonymous `benchmark_id`). `v_sb` is the pair's own deviation, learned from its
own labels. Priors were fitted by marginal likelihood on inner leave-benchmark-out folds. The prediction is the
posterior mean of the sigmoid (probit approximation), followed by an optional Platt recalibration per label stage. A
stage's recalibration is kept only where the cross-fitted calibration lowered the Brier score of that stage in the
cross-validation (stages 0, 1, 3, 7; the gain at stages 3 and 7 is tiny). Items without `benchmark_id` get the prior
prediction.

Item stage: if `labeled` contains responses of other subjects to the same item (same `item_content` and
`item_features` within the same `benchmark_id`), the target item gets a Laplace posterior offset
`d_i ~ N(0, tau_i2)` (tau_i2 = median empirical-Bayes Rasch item variance of the training benchmarks). Without such
labels the prediction equals the pair-level one exactly.

No `labeling.py`: the platform's random acquisition is used.

Robustness (v2.0-core): `predict` never raises. If the hierarchical model fails on an input it falls back to a
beta-binomial estimate from the pair's own labels (prior alpha, beta embedded in the state), and only if that fails
too to the constant 0.5. Labels are accepted as bool, int, float or strings ("1", "true", "yes", ...); unreadable
labels (None, NaN, other text) are skipped. The mathematics of the prediction is unchanged from v1 (bit-identical
on the cross-validation sets).

Runtime: `labeled` is grouped once per distinct label set. Up to 1,024 labels the set is identified by a hash over all
labels; above that by its length and 64 evenly spaced entries, so the per-call cost does not grow with the size of
`labeled` (this relies on `labeled` being the same for all inputs of a checkpoint and growing between checkpoints, as in
the platform protocol). Calls are serialised with a lock because the model keeps lazy caches.

## Data and licence

Fitted on `aims-foundations/measurement-db` (Hugging Face, revision `54074453da7b9911be0f48e4c560be547bc84d21`), curation
licensed CC BY-SA 4.0, individual benchmarks under their upstream licences. The embedded state contains only derived
parameters (one ability value and its variance per `normalized_name`, regression weights, hyperparameters); no item
text and no responses. Excluded from training: 64 bird_sql configurations graded 0 on all 360 questions and 12
swebench_live subjects carrying only successes (see the accompanying data-quality report).
